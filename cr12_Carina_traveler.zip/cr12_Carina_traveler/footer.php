
  <?php wp_footer(); ?>

<div id="footer_div">

	<div id="footer_div2">
		<div>&#169; TravelBloggers</div>
	</div>

</div>

</body>

</html>