

<?php get_header(); ?>


<div class="container-fluid main_container">

<div>
	<h1> Our travelers </h1>
</div>


<div class="card-deck" id="card-deck">

			<div class="card">
  						
    			<img class="card-img-top" src="#" height="180px">
   						 	
   				<div class="card-body">
      						
      			<h5 class="card-title"> card title </h5>

      			<p class="card-text">blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol blog entry Tirol</p><p class="trip_info"> Date: September 14-24, 2019 </p>

      			</div>
	
      		</div>

      		<div class="card">
  						
    			<img class="card-img-top" src="#" height="180px">
   						 	
   				<div class="card-body">
      						
      			<h5 class="card-title"> card title </h5>

      			<p class="card-text">blog entry York blog entry York  blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York blog entry York </p><p class="trip_info"> February 12-20, 2020 </p>

      			</div>
	
      		</div>

      		<div class="card">
  						
    			<img class="card-img-top" src="#" height="180px">
   						 	
   				<div class="card-body">
      						
      			<h5 class="card-title"> card title </h5>

      			<p class="card-text">blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca blog entry Mallorca  </p><p class="trip_info"> Date: March 1-7, 2020 </p>

      			</div>
	
      		</div>

      	</div>

</div>

  <?php get_footer(); ?>